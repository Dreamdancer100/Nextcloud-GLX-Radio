<?php

declare(strict_types=1);

namespace OCA\GlxRadio\Controller;

use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\AppFramework\Http\ContentSecurityPolicy;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\IRequest;

class PageController extends Controller {
    public function __construct(string $appName, IRequest $request) {
        parent::__construct($appName, $request);
    }

    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function index(): TemplateResponse {
        $response = new TemplateResponse('glxradio', 'main');

        // Sender-Icons (Favicons) kommen von beliebigen Radiosender-Domains,
        // nicht nur von unserer eigenen Nextcloud-Instanz. Die Standard-CSP
        // von Nextcloud erlaubt Bilder nur von 'self' - deshalb wurden Icons
        // bisher nie angezeigt, egal ob von radio-browser.info oder einem
        // selbst eingetragenen Link.
        $csp = new ContentSecurityPolicy();
        $csp->addAllowedImageDomain('*');

        // Die Sendersuche und "Sender entdecken" fragen direkt aus dem
        // Browser heraus die oeffentliche radio-browser.info-API ab. Je nach
        // Nextcloud-Version/Konfiguration erlaubt die Standard-CSP fuer
        // connect-src (XHR/fetch) nur 'self' und ein paar fest hinterlegte
        // Nextcloud-eigene Adressen - das wuerde diese Anfragen sonst
        // stillschweigend blockieren.
        $csp->addAllowedConnectDomain('https://de1.api.radio-browser.info');
        $csp->addAllowedConnectDomain('https://all.api.radio-browser.info');
        $response->setContentSecurityPolicy($csp);

        return $response;
    }
}
