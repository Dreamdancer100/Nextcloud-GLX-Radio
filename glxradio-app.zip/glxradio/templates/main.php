<?php
script('glxradio', 'glxradio-main');
style('glxradio', 'main');
?>
<div id="glxradio-app"></div>
