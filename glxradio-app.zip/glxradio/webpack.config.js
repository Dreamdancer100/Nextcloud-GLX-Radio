const webpackConfig = require('@nextcloud/webpack-vue-config')

webpackConfig.entry = {
    'main': require('path').join(__dirname, 'src', 'main.js'),
}

module.exports = webpackConfig
