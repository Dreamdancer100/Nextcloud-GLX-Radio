<?php

declare(strict_types=1);

return [
    'routes' => [
        ['name' => 'page#index', 'url' => '/', 'verb' => 'GET'],
        ['name' => 'favorites#list', 'url' => '/api/favorites', 'verb' => 'GET'],
        ['name' => 'favorites#save', 'url' => '/api/favorites', 'verb' => 'POST'],
        ['name' => 'stream_proxy#proxy', 'url' => '/api/proxy', 'verb' => 'GET'],
        ['name' => 'stream_proxy#nowPlaying', 'url' => '/api/nowplaying', 'verb' => 'GET'],
        ['name' => 'settings#get', 'url' => '/api/settings', 'verb' => 'GET'],
        ['name' => 'settings#save', 'url' => '/api/settings', 'verb' => 'POST'],
        ['name' => 'settings#addFolder', 'url' => '/api/folders', 'verb' => 'POST'],
        ['name' => 'settings#deleteFolder', 'url' => '/api/folders', 'verb' => 'DELETE'],
    ],
];
